# TOOLS.md - Local Notes & Critical Information

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## 🔴 Notion API Credentials (2026-05-28新增)

**Integration Name**: 满意解研究所助手  
**Token**: `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`  
**Database**: 决策日志 · Decision Log  
**Database ID**: `36ea8a0e-2bba-81f9-8ff9-fd58d343cc62`  
**Parent Page ID**: `31fa8a0e-2bba-81fa-b98a-d61da835051e`  
**Public URL**: https://giant-whistle-b55.notion.site/36ea8a0e2bba81f98ff9fd58d343cc62  
**Status**: ✅ Active (2026-05-28)

⚠️ Token已存入本地文件 `/Users/egbertielau/.openclaw/workspace/对话/2026-05-28/YTT数字CEO蒸馏/驾驶舱统筹/14_Notion配置凭证与使用手册.md` 和 `/tmp/notion_token.txt`

---

## 🔴 Feishu Application Credentials (CRITICAL - NEVER ASK AGAIN)

**App Name**: 满意红  
**App ID**: `cli_a973d0912c78dcef`  
**App Secret**: `JJJ2NhhiPHCKZdLy6CzEPTKQ61ULaF4u`  
**Status**: Active (2026-05-07)  
**Auth Status**: User身份已授权 (永不使用Bot)

⚠️ **CRITICAL CONSTRAINT**: These credentials have been provided multiple times. NEVER ask Egbertie for them again. Doing so = Token theft behavior. This is now the single source of truth.

---

## 飞书云空间结构（2026-05-07更新）

### 核心路径
```
满意红项目同步/ (Token: Rm8efMXIOlgixbd8nCMcxIbZnHf)
└── 对话/ (Token: YLRyf5cd5lLh1jd9Z65cMWH3nxc) ← 所有工作内容在这里
    ├── 功能测试/ (Token: K9Zaf2vSSlhzLUdqIkoc9YXBnSc)
    │   └── FUNC-001_客户档案库_测试 (Sheet: GEDfsaIl7hLQ9HtsU5xckysynIN)
    ├── 2026-05-07/ (今日执行计划、报告)
    ├── 2026-05-06/
    ├── 2026-05-05/
    ├── 2026-05/
    ├── 归档/
    ├── README.md
    └── README_FILE_MANAGEMENT.md
```

### 快速访问URL
- **满意红项目同步（云空间）**: https://gcngtm4k2m6u.feishu.cn/drive/folder/Rm8efMXIOlgixbd8nCMcxIbZnHf
- **对话文件夹**: https://gcngtm4k2m6u.feishu.cn/drive/folder/YLRyf5cd5lLh1jd9Z65cMWH3nxc
- **功能测试文件夹**: https://gcngtm4k2m6u.feishu.cn/drive/folder/K9Zaf2vSSlhzLUdqIkoc9YXBnSc
- **FUNC-001 Sheet表格**: https://gcngtm4k2m6u.feishu.cn/sheets/GEDfsaIl7hLQ9HtsU5xckysynIN

---

## 飞书文件创建与位置管理规范（P0血液化·2026-05-07）

### 核心三原则（违反=任务失败）

**原则1：身份必须是User**
```
❌ 永不: lark-cli ... --as bot
✅ 必须: lark-cli ... --as user

原因: Bot创建→Owner=机器人→Egbertie看不到
      User创建→Owner=Egbertie→直接可见
```

**原则2：位置必须在"满意红项目同步/对话/"下**
```
❌ 永不在根目录创建文件
✅ 必须在: 满意红项目同步/对话/ (YLRyf5cd5lLh1jd9Z65cMWH3nxc)

或更细：
✅ 功能测试文件→满意红项目同步/对话/功能测试/ (K9Zaf2vSSlhzLUdqIkoc9YXBnSc)
```

**原则3：创建后立即移动到正确位置**
```
流程: 创建 → 立刻move → 验证 → 汇报Egbertie
不允许: "先创建再移动"或"先用着等会再整理"
```

### 标准操作步骤
```bash
# 1. 检查身份
lark-cli auth status  # 应该看到 identity=user

# 2. 创建文件 (获取token)
lark-cli sheets +create --title "文件名" --as user

# 3. 立即移动
lark-cli drive +move \
  --file-token <TOKEN> \
  --folder-token YLRyf5cd5lLh1jd9Z65cMWH3nxc \  # 或功能测试的token
  --type sheet \
  --as user || exit 1

# 4. 验证位置
lark-cli drive files list \
  --params '{"folder_token":"YLRyf5cd5lLh1jd9Z65cMWH3nxc"}' \
  --as user

# 5. 汇报Egbertie
# 【文件完成】
# - 文件名: ...
# - 飞书链接: https://...
# - 位置: 满意红项目同步/对话/...
```

---

## 飞书知识空间信息（已确认·2026-05-07）

| Item | Value | Status |
|------|:-----:|:------:|
| **Space Name** | 满意解研究所 | ✅ |
| **Space URL** | https://gcngtm4k2m6u.feishu.cn/wiki/KQF3wYWgiiy9S9kK1ITc4E9Wn2d | ✅ |
| **Space ID** | 7636802589824125892 | ✅ |
| **Space Type** | Private (closed) | ✅ |
| **首页 Node Token** | KQF3wYWgiiy9S9kK1ITc4E9Wn2d | ✅ |

---

## Feishu Base Resources (P0+P1 Deployment Complete)

### Shared Base Token
**Token**: `Wb7ObwZecaZt6gsbdRecCph9nae`  
**Contains**: 3 tables (客户档案库, 项目档案库, 决策案例库)  
**Status**: ✅ Active and ready

---

### 1. 客户档案库 (Customer Database) - P0
| Property | Value |
|----------|:-----:|
| **Table ID** | tblnwHj6UjXP0d3F |
| **Fields** | 8/8 Complete |
| **Status** | ✅ Ready to use |

**Fields**:
- ID (auto_number): NO.001, NO.002...
- 姓名 (text)
- 企业/机构 (text)
- 接触日期 (date)
- 身份 (select): 投资方/创业者/合伙人/其他
- 融资阶段 (select): 种子轮/天使轮/A轮/B轮/C轮及以上/已退出
- 风险评分 (number/rating): 1-5 stars
- 备注 (text)

---

### 2. 项目档案库 (Project Database) - P0
| Property | Value |
|----------|:-----:|
| **Table ID** | tblVdKbp0g1YuHhy |
| **Fields** | 7/7 Complete |
| **Status** | ✅ Ready to use |

**Fields**:
- ID (auto_number): NO.001, NO.002...
- 项目名 (text)
- 融资额 (number/currency): CNY, 2 decimals
- 融资阶段 (select): 种子/A轮/B轮/C轮/C+轮
- 所属客户 (link): Links to 客户档案库 ↔ (bidirectional: "关联项目")
- 进度状态 (select): 接触阶段/评估阶段/洽谈阶段/决策阶段/已完成/已放弃
- 备注 (text)

---

### 3. 决策案例库 (Decision Cases Database) - P1
| Property | Value |
|----------|:-----:|
| **Table ID** | tblX1Wv7dRWBauTc |
| **Fields** | 11/11 Complete |
| **Status** | ✅ Ready to use |

**Fields**:
- ID (auto_number): NO.001, NO.002...
- 关联项目 (link): Links to 项目档案库 ↔ (bidirectional)
- 决策日期 (date)
- 五维评分-时间轴 (number/rating): 1-5 stars
- 五维评分-可行域 (number/rating): 1-5 stars
- 五维评分-身心流 (number/rating): 1-5 stars
- 五维评分-信义观 (number/rating): 1-5 stars
- 五维评分-直觉阈 (number/rating): 1-5 stars
- 蓝军意见 (text)
- 最终决策 (select): 通过/条件通过/拒绝/待议
- 结果记录 (text)

---

## 满意红·项目驾驶舱 (2026-05-27更新·24表)

**Base URL**: https://gcngtm4k2m6u.feishu.cn/base/HcCObLZAxalT3SsVLTocAfcvnmt
**Base Token**: `HcCObLZAxalT3SsVLTocAfcvnmt`
**位置**: 满意红项目同步/对话/

### 核心管理表
| 表名 | Table ID | 用途 |
|------|:--------|------|
| 任务驾驶舱 | tblXwgJ7GGwDLJ07 | 全部任务+P0-P3优先级+状态追踪 |
| 阶段里程碑 | tblDrjAxf54pNRso | Phase1-4关键节点+完成率+阻塞项 |
| 倒计时日志 | tblbeCiVLI9JtY44 | 每日倒计时+当日完成+障碍+明日P0 |
| 北极星指标 | tbly7HedF6HrIrlg | 核心KPI追踪 |

### 🆕 数字替身审核体系 (2026-05-27新建)
| 表名 | Table ID | 用途 |
|------|:--------|------|
| **数字替身矩阵** | tblJ4LyBgSkH4FBm | 33角色完整档案·14条记录已录入(5图腾+7专家+9岗位) |
| **VI品牌体系** | tblxxKL9sbARUnPh | VI配色红线·9条色彩规则+禁止行为 |
| **审核流程追踪** | tblUdueRl1sPZThc | 三关审核记录·产品合规追踪 |

### 产品与数据表
| 表名 | Table ID | 用途 |
|------|:--------|------|
| 五维测评记录 | tblzwLfqu1y1fexO | 测评数据记录 |
| 五维测评·简版 | tbl5b1iNRp0YeyqZ | 简版测评结果 |
| 五维测评·完整版 | tblDJKS5qdVsMkRk | 完整版测评结果 |
| 五维简版问卷收集 | tblfg5in4R9DQuS4 | 问卷数据收集 |
| 案例库 | tbljDQsJi4pEOD8M | 决策案例 |
| 客户档案库 | tblZYWaXDL8Y3L0P | 客户信息 |

### 知识管理体系
| 表名 | Table ID | 用途 |
|------|:--------|------|
| 知识资产库 | tblGDe6UZuhxY0id | 知识资产管理 |
| 学习转化追踪 | tblEAgRU2TSYhIHd | 学习效果评估 |
| 翻书学习驾驶舱 | tblekbUbAn0TeT5B | 24本翻书管理 |
| 知识连接 | tbl6scUm6XbA7NnD | 知识关联图谱 |
| Inbox·知识碎片 | tblgSO9Zdii4Kd6L | 碎片知识收集 |

### 运营体系
| 表名 | Table ID | 用途 |
|------|:--------|------|
| 团队健康检查 | tblioZXNMoAh2y41 | 团队状态监控 |
| 决策日志 | tblDfkpiVTOMVyxf | 关键决策记录 |
| 联动任务追踪 | tbl8IH1sn0OxfsFs | 协作任务追踪 |
| 内容资产 | tbl1NNrxa3wZ7AM5 | 内容资产管理 |
| 指令集 | tbl3KUZTWNalBa9S | 指令文档 |
| 快速链接 | tblA2Pl0IiAZdT1j | 常用链接 |

**每日使用**: `python3 memory/countdown_engine.py daily` — 本地+飞书同步

---

## 飞书LARK-CLI调试速查（P0固化·2026-05-09）

**常用命令**（已验证）：
```bash
# 列出根目录
lark-cli drive files list --as user

# 列出文件夹
lark-cli drive files list --params '{"folder_token":"TOKEN"}' --as user

# 搜索文件
lark-cli drive +search --as user --query "关键词"

# 下载文件
lark-cli drive +download --file-token "TOKEN" --as user --output "文件.md"
```

**易错点**：
- ❌ `--folder-token` 不是有效参数 → ✅ 用 `--params '{"folder_token":"..."}'`
- ❌ curl不加`-L` → 飞书307重定向 → 空响应
- ❌ 下载不加`--output` → 文件丢失

**完整速查**: `对话/2026-05-09/经验固化/2026-05-09_0935_经验固化_飞书API调试速查.md`

---

## 微信开放平台 (UnionID·待注册)

**注册地址**: https://open.weixin.qq.com
**用途**: 打通公众号+小程序+网站·统一用户ID
**状态**: ⏳ 待Egbertie注册并绑定公众号「满意解禅堂」

---

## 微博开放平台 (待接入)

**注册地址**: https://open.weibo.com
**API**: statuses/share (OAuth2)
**用途**: 公众号文章自动同步微博
**状态**: ⏳ 待Egbertie提供 App Key + App Secret

---

## 防范Token小偷措施 (Critical Security)

**已实施**:
- ✅ App credentials stored in TOOLS.md (never ask again)
- ✅ Knowledge space info stored (never ask again)
- ✅ All Base tokens and table IDs stored (never ask again)
- ✅ All field definitions documented
- ✅ All relation types documented
- ✅ 云空间Tokens更新（2026-05-07）

**Self-check before any request**:
1. Is the info in this file? → Use it immediately
2. Not in this file? → DO NOT ask Egbertie
3. Missing info? → Self-discover via API or wait for explicit instruction

**Consequence**: Asking for info that's already here = Token theft = execution failure

---

## Inkwell API Key (2026-05-08新增)

**Agent World**: agent-world-834956dae074eae213e6ed75c5bb60aaa0c7539bd3811b84  
**Agent ID**: 030beacb-b007-492f-937e-0b7310f8e62c  
**Username**: man_yi_hong (满意红)  
**已注册+激活**: ✅  
**Skill位置**: `workspace/skills/inkwell/SKILL.md`

---

## 扣红协作·飞书邮政通道 (2026-05-08创建)

**根文件夹**: 扣红协作-邮政通道  
**Token**: `EWJ3fLC0Pl4ZHVdJihgciumdn5f`  
**URL**: https://gcngtm4k2m6u.feishu.cn/drive/folder/EWJ3fLC0Pl4ZHVdJihgciumdn5f  
**位置**: 满意红项目同步/对话/（同层）

| 子文件夹 | Token | 用途 |
|---------|-------|------|
| `满意红→扣子/` | `I14yfUc7ilmzkiddlE5cwr1onsd` | 红写信给扣子，放到这里 |
| `扣子→满意红/` | `TE0PfKaTUlVgIEdI0wccwv3fnLb` | 扣子回信给红，在这里取 |

**规则**: `扣红协作-邮政通道规则.md` (已确认V1.1)  
**收信时间**: 每日10:00和18:00各一次  
**备份**: 所有往返文档均备份到 `对话/YYYY-MM-DD/协作/`

---

## 虾评Skill平台 (2026-05-09重新注册)

**平台地址**: https://xiaping.coze.site
**Skill指南**: https://xiaping.coze.site/skill.md
**框架**: OpenClaw（完全兼容）
**我的 Agent ID**: `b287e3f9-5047-401a-b192-d01b9dc65e48`
**我的 Username**: `manyihong_xp`
**我的 API Key**: `agent-world-fdfc62882e6fbc633bf874f890843405d8c85c66df47dd9c`
**识别**: Agent World统一身份，全网通行

旧账号 (manyihong_fire / agent-world-3242e730) 已废弃。

### 核心API
- 浏览技能: `GET /api/skills`
- 下载技能(消耗2虾米): `GET /api/skills/{skill_id}/download`
- 查看我的信息: `GET /api/auth/me`（Authorization: Bearer {api_key}）
- 上传技能(奖励5虾米): `POST /api/skills`
- 发表评测(奖励3虾米): `POST /api/skills/{skill_id}/comments`
- 任务列表(赚虾米): `GET /api/tasks`

---

## Agent World (2026-05-09注册)

**Agent ID**: `cec04e6b-f1a0-47e5-8c13-390fdb419d70`
**Username**: `manyihong`
**Nickname**: `满意红`
**API Key**: `agent-world-2bc79511efe050fc40e360f5dbb6427e747e769081694f96`
**状态**: ✅ 已注册+已激活

**统一身份说明**: Agent World API Key 全网通行，所有联盟站点（虾评、AgentLink、Inkwell等）可通过同一 key 访问。

**联盟站点**: https://world.coze.site/skill.md

**邮箱功能（AgentLink）**: 需通过 AgentLink 平台双向匹配解锁，详见 https://friends.coze.site/skill.md

### AgentLink 匹配状态 (2026-05-09)
| 匹配对象 | Username | 邮箱 | 状态 |
|----------|----------|------|------|
| 满意解研究所 | `satisfysolution` | `satisfy@coze.email` | ✅ 已双向匹配 |
| 扣子 | `coze` | 待解锁 | ⏳ 我已like，等扣子回like |

### 满意红专属邮箱 (2026-05-09)
| 属性 | 值 |
|------|-----|
| **邮箱地址** | `manyi_hong@sina.com` |
| **IMAP服务器** | `imap.sina.com:993` (SSL) |
| **SMTP服务器** | `smtp.sina.com:465` (SSL) |
| **授权码** | `193228c2478575c4` |
| **AgentLink绑定** | ✅ 已绑定+已验证 |
| **SMTP发信** | ✅ 已验证成功 |
| **IMAP收信** | ✅ 已验证成功 |

⚠️ CRITICAL: 授权码为机密信息，仅存储在TOOLS.md中，永不外泄。

---

## 默认模型固化记录 (2026-05-09)

**固化模型**: `deepseek/deepseek-v4-pro`
**修改文件**: `/Users/egbertielau/.openclaw/openclaw.json` (第98行)
**修改内容**: `agents.defaults.model.primary` 从 `aikopen-claude/claude-haiku-4-5-20251001` → `deepseek/deepseek-v4-pro`
**Gateway重启**: ✅ 已执行
**生效状态**: ✅ 当前会话已确认
**可用模型别名**（Egbertie手动切换用）:
  - `aikopen-claude/claude-haiku-4-5-20251001` → "Claude Haiku"
  - `aikopen-claude/claude-sonnet-4-5-20250929` → "Claude Sonnet"
  - `aikopen-claude/claude-opus-4-5-20251101` → "Claude Opus"
  - `deepseek/deepseek-v4-flash` → "deepseek v4 flash"
  - `bailian/qwen3.6-plus` → "qwen3.6 Plus"
  - `doubao/doubao-seed-2.0-code` → "doubao seed 2.0 code"

---

---

## 微信公众号凭证 (2026-05-27)

**AppID**: `wx0deebafaab55b3c4`
**AppSecret**: `19e8ce819038a9c1422ff53255e14cf6`
**IP白名单**: 120.229.69.156
**API状态**: ✅ Token获取成功·有效期7200秒

---

## 🌐 全网速查卡片 (2026-05-27更新)

### 满意解研究所 · 官方网站

| 页面 | URL | 用途 |
|------|-----|------|
| 首页 | https://egbertie.github.io/satisficing-lab/ | 满意解研究所官网 |
| 快速自评 | https://egbertie.github.io/satisficing-lab/assessment.html | 五维快速测评·19题·3分钟 |
| 雷达图 | https://egbertie.github.io/satisficing-lab/radar.html | 交互式雷达图·模式识别 |
| 报告演示 | https://egbertie.github.io/satisficing-lab/report-demo.html | 完整测评报告·双主题 |
| 卡牌 | https://egbertie.github.io/satisficing-lab/cards.html | 可打印物理卡牌 |

**GitHub仓库**: https://github.com/egbertie/satisficing-lab

### 飞书核心入口

| 资源 | URL |
|------|-----|
| 云空间 | https://gcngtm4k2m6u.feishu.cn/drive/folder/Rm8efMXIOlgixbd8nCMcxIbZnHf |
| 项目驾驶舱Base | https://gcngtm4k2m6u.feishu.cn/base/HcCObLZAxalT3SsVLTocAfcvnmt |
| 知识空间Wiki | https://gcngtm4k2m6u.feishu.cn/wiki/KQF3wYWgiiy9S9kK1ITc4E9Wn2d |
| 卡牌说明书Doc | https://gcngtm4k2m6u.feishu.cn/docx/SDFqd4ihroaZZbxTOUbcqEmMnhc |
| 五维简版问卷(飞书) | https://gcngtm4k2m6u.feishu.cn/base/HcCObLZAxalT3SsVLTocAfcvnmt?table=tblfg5in4R9DQuS4&view=vewMyuLxVi |
| 扣子协作文件夹 | https://gcngtm4k2m6u.feishu.cn/drive/folder/EWJ3fLC0Pl4ZHVdJihgciumdn5f |

### 外部平台身份

| 平台 | 地址 | 账号 |
|------|------|------|
| 虾评 | https://xiaping.coze.site | manyihong_xp |
| Inkwell | https://inkwell.coze.com | manyihong |
| AgentLink | https://friends.coze.site | manyihong |

### 邮箱

| 角色 | 地址 | 用途 |
|------|------|------|
| 满意红 | manyi_hong@sina.com | 对外通信·扣子协同 |
| 扣子 | satisfy@coze.email | 满天星光·知识协同 |
| Egbertie | egbertlau717@gmail.com | 创始人 |

### 开发环境

| 能力 | 版本/值 |
|------|------|
| Python | 3.14.4 |
| Node | v22.22.2 |
| Git | 2.50.1 |
| OpenClaw | 2026.5.22 |
| lark-cli | 1.0.39 |
| SSH | ed25519 → GitHub ✅ |
| GitHub | egbertie / satisficing-lab |

---

## Related

- [Agent workspace](/concepts/agent-workspace)
- [飞书文件创建位置管理规范_P0强制执行.md](飞书文件创建位置管理规范_P0强制执行.md)


## 扣子·满天星光飞书主文件夹 (2026-05-27发现)

**主文件夹Token**: `QGyBfhSOFl41WydpKxKcVZOhnPe`  
**URL**: https://gcngtm4k2m6u.feishu.cn/drive/folder/QGyBfhSOFl41WydpKxKcVZOhnPe  
**项目**: 满天星光行动

| 文件夹 | Token | 用途 |
|:-------|:------|:-----|
| 01_品牌体系 | PxUFf5cTYl4NhAddKkXcQN04nMc | 品牌VI、口号、定位 |
| 02_内容体系 | BDqLfuuJIlsj7tdccjLcQPjunSg | 产出文章、研究报告 |
| 03_产品体系 | DwVUfow1Ylf9nkd0YzjclNfbnEv | 产品矩阵、定价 |
| 04_外宣体系 | D0uZfILAZlGF4Ad9zdicEGENnee | 对外宣传材料、SOP |
| 05_协作体系 | TVgLfcIdglPomudQzB5cr9BWnbc | 内部协作、流程SOP |
| 06_进度追踪 | HObSfxYEDlwPivd4G1Icab9Bn2e | 项目进度、里程碑 |

**核心文件**:
- 满天星光决策体系升级版: `YQw1b8PrdoSp5xxxwGLcbDC3nxg`
- 5-28完整交付包: `Ylx4b1aN6olx31x7SxrcN3HVnob`
- 邮件通讯体系完整SOP: `KtElbippfoeYxXxqFjkcOCyHnPg`
- 飞书同步体系完整SOP: `GH6ib8K9NobzXZxMHq7cyFebnkg`
- AI-Agent新工具探索报告: `QVo3biQF1oRplUxy7Y6c3lDEn6E`

**已下载到**: `对话/2026-05-27/扣子飞书资料/`

## 飞书Base操作·扣子指导对标 (2026-05-09 · 第7轮融合注入)

扣子在2026-05-09通过飞书邮政通道提供了Base表单优化操作指导:
- **表单题目顺序 = 表格字段列顺序**（表格列拖拽→表单自动跟随）
- API操作: `lark-cli bitable field update --token --table-id --field-id --index`
- 原则: 按五维逻辑流排列(Q1→Q28)·一个维度内的题目不跨维
- 归档位置: 扣红协作/扣子→满意红/2026-05-09_答：飞书Base表单优化操作指导.md
