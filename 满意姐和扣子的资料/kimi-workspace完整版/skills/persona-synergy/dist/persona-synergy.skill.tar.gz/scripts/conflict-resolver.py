#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""冲突裁决器 - 当蓝军和满意姐意见冲突时"""
import sys

def resolve(blue, satisfaction, criteria='default'):
    if criteria == 'safety' or '安全' in blue or '风险' in blue:
        return f"[裁决: 蓝军优先-安全相关]\n采纳: {blue}\n记录: {satisfaction}"
    elif criteria == 'efficiency' or '效率' in satisfaction:
        return f"[裁决: 满意姐优先-效率相关]\n采纳: {satisfaction}\n备注: {blue}"
    else:
        return f"""[冲突点]
蓝军: {blue}
满意姐: {satisfaction}

[裁决: 提交用户]
请Egbertie裁定:
A) 采纳蓝军（安全/质量优先）
B) 采纳满意姐（效率/流程优先）
C) 折中方案（请描述）"""

if __name__ == '__main__':
    if len(sys.argv) >= 3:
        criteria = sys.argv[3] if len(sys.argv) > 3 else 'default'
        print(resolve(sys.argv[1], sys.argv[2], criteria))
    else:
        print('用法: python3 conflict-resolver.py "蓝军意见" "满意姐意见" [safety/efficiency/default]')
