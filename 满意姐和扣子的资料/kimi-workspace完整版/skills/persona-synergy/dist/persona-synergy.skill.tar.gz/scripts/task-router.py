#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""任务路由器 - 根据任务内容判断最佳协同模式"""
import sys

def route_task(task_description):
    task = task_description.lower()
    if any(k in task for k in ['审计','检查','复盘','审查','验证']):
        return '模式C（蓝军主导审计）'
    elif any(k in task for k in ['决策','评估','选择','判断','投','并购','合伙']):
        return '模式B（并行协同-决策需双视角）'
    elif any(k in task for k in ['写','创作','生成','制作','整理']):
        return '模式A（顺序协同-先流程后审计）'
    else:
        return '模式A（顺序协同-默认）'

if __name__ == '__main__':
    if len(sys.argv) > 1:
        print(route_task(' '.join(sys.argv[1:])))
    else:
        print('用法: python3 task-router.py "任务描述"')
