#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""防火墙筛选器 - 信息优先级自动评估"""
import sys

def filter_info(title, source, date, topic):
    score = 0
    # 时效性
    if '2026' in date or '今天' in date: score += 3
    elif '2025' in date: score += 1
    # 信源
    if source in ['学术期刊','官方报告','权威媒体']: score += 3
    elif source in ['行业媒体','知名博主']: score += 1
    # 相关性
    if topic in ['合伙人决策','知识传承','AI应用']: score += 3
    elif topic in ['管理','创业','科技']: score += 1
    
    if score >= 7: return 'P0-必读'
    elif score >= 4: return 'P1-选读'
    elif score >= 2: return 'P2-参考'
    else: return 'P3-忽略'

if __name__ == '__main__':
    if len(sys.argv) >= 5:
        print(filter_info(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]))
    else:
        print('用法: python3 firewall-filter.py "标题" "来源" "日期" "主题"')
